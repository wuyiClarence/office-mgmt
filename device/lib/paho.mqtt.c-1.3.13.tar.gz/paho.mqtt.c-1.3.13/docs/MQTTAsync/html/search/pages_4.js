var searchData=
[
  ['subscription_20example_705',['Subscription example',['../subscribe.html',1,'']]],
  ['subscription_20wildcards_706',['Subscription wildcards',['../wildcard.html',1,'']]]
];
